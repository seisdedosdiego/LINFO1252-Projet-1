#!/bin/bash

echo "Test philosophes"
./philosophes 4

echo "Test prod-cons"
./prod-cons 2 2

echo "Test lecteurs-écrivains"
./lecteurs-ecrivains 2 2
